------------------------------
-----CORRECTION TOOL V1.0-----
------------------------------

Herzlichen Dank das Sie sich f�r das Correctiontool entschieden haben. Ich hoffe es kann Ihnen die Arbeit ein wenig erleichtern.
Denoch gibt es ein paar wenige Aufgaben die Sie leider immer noch selber zu korrigieren haben. Nun ist aber genug gesagt, weiter geht
es mit der Schritt-f�r-Schritt Anleitung.


Anleitung:

1.Starten Sie die zu korrigierende VM

2.Kopieren sie den Inhalt des Ordner "Schritt 1" nach C:\users\Public

3.Kopieren Sie den Inhalt des Ordner "Schritt 2" nach C:\users\Admin\Desktop

4.Suchen Sie in der Windows Suchleiste nach PowerShell ISE und �ffnen Sie diese als Administrator

5.Geben Sie folgenden Befehl in die Befehlszeile ein (blauer Abschnitt) : Set-ExecutionPolicy -ExecutionPolicy bypass

6.Best�tigen Sie mit "Ja,alle"

7.�ffnen Sie nun die CorrectionTool.ps1 Datei mit CTRL + o (C:\users\Admin\Desktop) und f�hren sie diese aus (F5)

8.Das Ergebnis k�nnen Sie unter C:\users\Public\CorrectionTool.txt einsehen  



Januar 2018,Bj�rn Burkard
